esto es vsftpd

#linux

![](https://www.youtube.com/watch?v=64pI_dKYZOg)

![[VSFTPD_IMG.jpg]]

Emojis de prueba: 😀👍